// ========================================
// Seagull Power — Telegram Bot + Web App
// ========================================
// npm install node-telegram-bot-api
// node bot.js
// ========================================

const TelegramBot = require('node-telegram-bot-api');

const TOKEN = '8451725355:AAFj_4J5vF6TjpJlq1SmySEgnZnni7fN3HE';

// ⚠️ غيّر هذا الرابط لرابط صفحتك المستضافة (HTTPS مطلوب)
const WEBAPP_URL = 'https://YOUR-DOMAIN.com/calculator.html';

const bot = new TelegramBot(TOKEN, { polling: true });

// ===== حالات المحادثة =====
const sessions = {};
function getSession(chatId) { if (!sessions[chatId]) sessions[chatId] = { step: 'idle' }; return sessions[chatId]; }
function resetSession(chatId) { sessions[chatId] = { step: 'idle' }; }

// ===== رسالة الترحيب =====
function sendWelcome(chatId) {
  const msg =
    `⚡ *مرحباً بك في Seagull Power*\n` +
    `☀️ _حاسبة منظومات الطاقة الشمسية — العراق_\n\n` +
    `━━━━━━━━━━━━━━━━━━\n\n` +
    `أقدر أساعدك بحساب:\n` +
    `🔆 عدد الألواح الشمسية\n` +
    `🔌 عدد الإنفرترات\n` +
    `🔋 سعة البطاريات المطلوبة\n\n` +
    `━━━━━━━━━━━━━━━━━━\n\n` +
    `اختر طريقة الحساب:`;

  bot.sendMessage(chatId, msg, {
    parse_mode: 'Markdown',
    reply_markup: {
      keyboard: [
        [{ text: '☀️ فتح حاسبة الطاقة', web_app: { url: WEBAPP_URL } }],
        [{ text: '⌨️ حاسبة نصية (داخل المحادثة)' }],
        [{ text: '📞 تواصل معنا' }, { text: 'ℹ️ عن الشركة' }],
      ],
      resize_keyboard: true,
    },
  });
}

// ===== /start =====
bot.onText(/\/start/, (msg) => {
  resetSession(msg.chat.id);
  sendWelcome(msg.chat.id);
});

// ===== استقبال بيانات Web App =====
bot.on('web_app_data', (msg) => {
  try {
    const data = JSON.parse(msg.web_app_data.data);
    if (data.action === 'calc_result' && data.text) {
      bot.sendMessage(msg.chat.id, data.text, {
        reply_markup: {
          keyboard: [
            [{ text: '☀️ فتح حاسبة الطاقة', web_app: { url: WEBAPP_URL } }],
            [{ text: '📞 أريد التواصل للتركيب' }],
            [{ text: '🔙 رجوع للقائمة' }],
          ],
          resize_keyboard: true,
        },
      });
    }
  } catch (e) {
    console.error('Web App data error:', e);
  }
});

// ===== معالجة الرسائل =====
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();
  const session = getSession(chatId);

  if (text.startsWith('/')) return;
  if (msg.web_app_data) return;

  // ===== القائمة الرئيسية =====
  if (text === '⌨️ حاسبة نصية (داخل المحادثة)') {
    resetSession(chatId);
    session.step = 'ask_amps';
    return bot.sendMessage(chatId,
      `🔆 *حاسبة الطاقة الشمسية*\n\n📝 *الخطوة 1 من 5*\n\n⚡ كم أمبير تحتاج؟\n_(مثال: 30)_`,
      { parse_mode: 'Markdown' }
    );
  }

  if (text === '📞 تواصل معنا' || text === '📞 أريد التواصل للتركيب') {
    return bot.sendMessage(chatId,
      `📞 *تواصل مع Seagull Power*\n\n━━━━━━━━━━━━━━━━━━\n📱 هاتف: 07XX XXX XXXX\n📍 الموقع: بغداد — العراق\n\n_يسعدنا خدمتك!_`,
      { parse_mode: 'Markdown' }
    );
  }

  if (text === 'ℹ️ عن الشركة') {
    return bot.sendMessage(chatId,
      `⚡ *Seagull Power*\n\n━━━━━━━━━━━━━━━━━━\nشركة متخصصة بتصميم وتركيب\nمنظومات الطاقة الشمسية في العراق\n\n✅ أوف-غريد\n✅ هايبرد\n✅ أون-غريد\n✅ صيانة دورية\n\n_طاقة مستدامة للعراق_ ☀️`,
      { parse_mode: 'Markdown' }
    );
  }

  if (text === '🔙 رجوع للقائمة') {
    resetSession(chatId);
    return sendWelcome(chatId);
  }

  if (text === '🔄 حساب منظومة جديدة') {
    resetSession(chatId);
    session.step = 'ask_amps';
    return bot.sendMessage(chatId,
      `🔆 *حاسبة الطاقة الشمسية*\n\n📝 *الخطوة 1 من 5*\n\n⚡ كم أمبير تحتاج؟\n_(مثال: 30)_`,
      { parse_mode: 'Markdown' }
    );
  }

  // ===== خطوات الحاسبة النصية =====

  if (session.step === 'ask_amps') {
    const val = parseFloat(text);
    if (isNaN(val) || val <= 0) return bot.sendMessage(chatId, '❌ أدخل رقم صحيح للأمبيرات _(مثال: 30)_', { parse_mode: 'Markdown' });
    session.amps = val;
    session.step = 'ask_panel';
    return bot.sendMessage(chatId,
      `✅ الأمبيرات: *${val}A*\n\n📝 *الخطوة 2 من 5*\n\n🔆 قدرة اللوح الشمسي (W)؟`,
      { parse_mode: 'Markdown', reply_markup: { keyboard: [[{ text: '550' }, { text: '450' }, { text: '400' }], [{ text: '🔙 رجوع للقائمة' }]], resize_keyboard: true, one_time_keyboard: true } }
    );
  }

  if (session.step === 'ask_panel') {
    if (text === '🔙 رجوع للقائمة') { resetSession(chatId); return sendWelcome(chatId); }
    const val = parseFloat(text);
    if (isNaN(val) || val <= 0) return bot.sendMessage(chatId, '❌ أدخل قدرة اللوح بالواط');
    session.panelW = val;
    session.step = 'ask_inverter';
    return bot.sendMessage(chatId,
      `✅ قدرة اللوح: *${val}W*\n\n📝 *الخطوة 3 من 5*\n\n🔌 قدرة الإنفرتر (W)؟`,
      { parse_mode: 'Markdown', reply_markup: { keyboard: [[{ text: '3000' }, { text: '5000' }, { text: '8000' }], [{ text: '10000' }, { text: '12000' }], [{ text: '🔙 رجوع للقائمة' }]], resize_keyboard: true, one_time_keyboard: true } }
    );
  }

  if (session.step === 'ask_inverter') {
    if (text === '🔙 رجوع للقائمة') { resetSession(chatId); return sendWelcome(chatId); }
    const val = parseFloat(text);
    if (isNaN(val) || val <= 0) return bot.sendMessage(chatId, '❌ أدخل قدرة الإنفرتر بالواط');
    session.invW = val;
    session.step = 'ask_night';
    return bot.sendMessage(chatId,
      `✅ الإنفرتر: *${val}W*\n\n📝 *الخطوة 4 من 5*\n\n🌙 ساعات التشغيل الليلي؟`,
      { parse_mode: 'Markdown', reply_markup: { keyboard: [[{ text: '3' }, { text: '4' }, { text: '5' }, { text: '6' }], [{ text: '8' }, { text: '10' }, { text: '12' }], [{ text: '🔙 رجوع للقائمة' }]], resize_keyboard: true, one_time_keyboard: true } }
    );
  }

  if (session.step === 'ask_night') {
    if (text === '🔙 رجوع للقائمة') { resetSession(chatId); return sendWelcome(chatId); }
    const val = parseFloat(text);
    if (isNaN(val) || val < 1 || val > 12) return bot.sendMessage(chatId, '❌ أدخل رقم بين 1 و 12');
    session.nightHours = val;
    session.step = 'ask_watani';
    return bot.sendMessage(chatId,
      `✅ ساعات الليل: *${val}h*\n\n📝 *الخطوة 5 من 5*\n\n🏠 ساعات الكهرباء الوطني؟`,
      { parse_mode: 'Markdown', reply_markup: { keyboard: [[{ text: '🔌 بدون وطني (أوف-غريد)' }], [{ text: '⚡ 6 ساعات وطني (هايبرد)' }], [{ text: '⚡ 12 ساعة وطني (هايبرد)' }], [{ text: '🔙 رجوع للقائمة' }]], resize_keyboard: true, one_time_keyboard: true } }
    );
  }

  if (session.step === 'ask_watani') {
    if (text === '🔙 رجوع للقائمة') { resetSession(chatId); return sendWelcome(chatId); }
    let wh = 0;
    if (text.includes('6 ساعات')) wh = 6;
    else if (text.includes('12 ساعة')) wh = 12;
    else if (text.includes('بدون وطني')) wh = 0;
    else return bot.sendMessage(chatId, '❌ اختر من الأزرار');

    const { amps, panelW, invW, nightHours } = session;
    const battCapAh = (nightHours * amps * 220) / 0.8;
    const basePanels = Math.ceil((amps * 220) / panelW);
    let numPanels;
    if (wh === 12) numPanels = basePanels;
    else if (wh === 6) numPanels = basePanels + Math.ceil((battCapAh * 0.5 * 0.8) / (5 * panelW));
    else numPanels = basePanels + Math.ceil((battCapAh * 0.8) / (5 * panelW));

    let loadW = wh === 0 ? amps * 220 * 1.2 : amps * 220;
    const numInv = Math.ceil(loadW / invW);
    const totalKWp = (numPanels * panelW / 1000).toFixed(1);
    const totalInvKW = (numInv * invW / 1000).toFixed(1);
    const wataniLabel = wh === 0 ? 'بدون وطني (أوف-غريد)' : wh + ' ساعة وطني (هايبرد)';

    const result =
      `☀️ *نتائج تصميم المنظومة*
━━━━━━━━━━━━━━━━━━

📋 *البيانات:*
▫️ الأمبيرات: ${amps}A
▫️ اللوح: ${panelW}W | الإنفرتر: ${(invW / 1000).toFixed(1)}kW
▫️ ساعات الليل: ${nightHours}h | ${wataniLabel}

━━━━━━━━━━━━━━━━━━

🔆 *الألواح:* ${numPanels} لوح (${totalKWp} kWp)
🔌 *الإنفرترات:* ${numInv} (${totalInvKW}kW)${wh === 0 ? ' — أمان 1.2' : ''}
🔋 *البطاريات:* ${Math.ceil(battCapAh)} Ah

━━━━━━━━━━━━━━━━━━
📊 الحمل: *${amps * 220}W*

_Seagull Power — طاقة مستدامة للعراق_ ☀️`;

    bot.sendMessage(chatId, result, {
      parse_mode: 'Markdown',
      reply_markup: { keyboard: [[{ text: '🔄 حساب منظومة جديدة' }], [{ text: '📞 أريد التواصل للتركيب' }], [{ text: '🔙 رجوع للقائمة' }]], resize_keyboard: true }
    });

    console.log(`[حساب] ${msg.from.first_name || ''} @${msg.from.username || '—'} | ${amps}A | ${numPanels} panels | ${Math.ceil(battCapAh)}Ah`);
    resetSession(chatId);
    return;
  }

  // رسالة غير معروفة
  sendWelcome(chatId);
});

console.log('');
console.log('⚡ ==========================================');
console.log('   Seagull Power Bot is RUNNING!');
console.log('   البوت شغال... انتظر الرسائل');
console.log('⚡ ==========================================');
console.log('');
